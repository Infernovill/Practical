```python
import pandas as np
Salary = np.read_csv(r"C:\Users\rafyq\OneDrive\Desktop\Sal_vs_Exp.csv")
Salary
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Years of Experience</th>
      <th>Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1036</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>1041</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1054</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1069</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1110</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4995</th>
      <td>29</td>
      <td>99841</td>
    </tr>
    <tr>
      <th>4996</th>
      <td>29</td>
      <td>99934</td>
    </tr>
    <tr>
      <th>4997</th>
      <td>29</td>
      <td>99940</td>
    </tr>
    <tr>
      <th>4998</th>
      <td>29</td>
      <td>99941</td>
    </tr>
    <tr>
      <th>4999</th>
      <td>29</td>
      <td>99980</td>
    </tr>
  </tbody>
</table>
<p>5000 rows × 2 columns</p>
</div>




```python
# objective function
def objective(x = 'Years of Experience', y = 'Salary'):
    return x + y
```


```python
# 3d plot of the test function
from numpy import arange
from numpy import meshgrid
from matplotlib import pyplot

# define range for input
r_min, r_max = -1.0, 1.0
# sample input range uniformly at 0.1 increments
xaxis = arange(r_min, r_max, 0.1)
yaxis = arange(r_min, r_max, 0.1)
# create a mesh from the axis
x, y = meshgrid(xaxis, yaxis)
# compute targets
results = objective(x, y)
# create a surface plot with the jet color scheme
figure = pyplot.figure()
axis = figure.gca(projection='3d')
axis.plot_surface(x, y, results, cmap='jet')
# show the plot
pyplot.show()
```


    
![png](output_2_0.png)
    



```python
# contour plot of the test function
from numpy import asarray
from numpy import arange
from numpy import meshgrid
from matplotlib import pyplot


# define range for input
bounds = asarray([[-1.0, 1.0], [-1.0, 1.0]])
# sample input range uniformly at 0.1 increments
xaxis = arange(bounds[0,0], bounds[0,1], 0.1)
yaxis = arange(bounds[1,0], bounds[1,1], 0.1)
# create a mesh from the axis
x, y = meshgrid(xaxis, yaxis)
# compute targets
results = objective(x, y)
# create a filled contour plot with 50 levels and jet color scheme
pyplot.contourf(x, y, results, levels=50, cmap='jet')
# show the plot
pyplot.show()
```


    
![png](output_3_0.png)
    



```python
# gradient descent optimization with nesterov momentum for a two-dimensional test function
from math import sqrt
from numpy import asarray
from numpy.random import rand
from numpy.random import seed



# derivative of objective function
def derivative(x, y):
    return asarray([x, y])

# gradient descent algorithm with nesterov momentum
def nesterov(objective, derivative, bounds, n_iter, step_size, momentum):
# generate an initial point
    solution = bounds[:, 0] + rand(len(bounds)) * (bounds[:, 1] - bounds[:, 0])
# list of changes made to each variable
    change = [0.0 for _ in range(bounds.shape[0])]
# run the gradient descent
    for it in range(n_iter):
# calculate the projected solution
        projected = [solution[i] + momentum * change[i] for i in range(solution.shape[0])]
# calculate the gradient for the projection
        gradient = derivative(projected[0], projected[1])
# build a solution one variable at a time
        new_solution = list()
        for i in range(solution.shape[0]):
# calculate the change
            change[i] = (momentum * change[i]) - step_size * gradient[i]
# calculate the new position in this variable
            value = solution[i] + change[i]
# store this variable
            new_solution.append(value)
# evaluate candidate point
        solution = asarray(new_solution)
        solution_eval = objective(solution[0], solution[1])
# report progress
        print('>%d f(%s) = %.5f' % (it, solution, solution_eval))
    return [solution, solution_eval]

# seed the pseudo random number generator
seed(1)
# define range for input
bounds = asarray([[-1.0, 1.0], [-1.0, 1.0]])
# define the total iterations
n_iter = 30
# define the step size
step_size = 0.1
# define momentum
momentum = 0.3
# perform the gradient descent search with nesterov momentum
best, score = nesterov(objective, derivative, bounds, n_iter, step_size, momentum)
print('Done!')
print('f(%s) = %f' % (best, score))
```

    >0 f([-0.14936039  0.39658409]) = 0.17959
    >1 f([-0.12994354  0.34502816]) = 0.13593
    >2 f([-0.11170664  0.29660524]) = 0.10045
    >3 f([-0.09561201  0.25387053]) = 0.07359
    >4 f([-0.08170526  0.2169451 ]) = 0.05374
    >5 f([-0.06977991  0.18528073]) = 0.03920
    >6 f([-0.05958208  0.15820327]) = 0.02858
    >7 f([-0.05087045  0.13507203]) = 0.02083
    >8 f([-0.04343127  0.1153194 ]) = 0.01518
    >9 f([-0.03707956  0.09845424]) = 0.01107
    >10 f([-0.03165665  0.08405523]) = 0.00807
    >11 f([-0.02702679  0.07176197]) = 0.00588
    >12 f([-0.02307405  0.06126659]) = 0.00429
    >13 f([-0.01969941  0.05230618]) = 0.00312
    >14 f([-0.01681831  0.04465625]) = 0.00228
    >15 f([-0.01435859  0.03812515]) = 0.00166
    >16 f([-0.0122586   0.03254923]) = 0.00121
    >17 f([-0.01046575  0.02778881]) = 0.00088
    >18 f([-0.0089351   0.02372462]) = 0.00064
    >19 f([-0.00762832  0.02025482]) = 0.00047
    >20 f([-0.00651265  0.0172925 ]) = 0.00034
    >21 f([-0.00556016  0.01476342]) = 0.00025
    >22 f([-0.00474697  0.01260423]) = 0.00018
    >23 f([-0.00405271  0.01076082]) = 0.00013
    >24 f([-0.00345999  0.00918702]) = 0.00010
    >25 f([-0.00295396  0.00784339]) = 0.00007
    >26 f([-0.00252193  0.00669627]) = 0.00005
    >27 f([-0.00215309  0.00571692]) = 0.00004
    >28 f([-0.0018382   0.00488081]) = 0.00003
    >29 f([-0.00156935  0.00416697]) = 0.00002
    Done!
    f([-0.00156935  0.00416697]) = 0.000020
    


```python
# gradient descent algorithm with nesterov momentum
def nesterov(objective, derivative, bounds, n_iter, step_size, momentum):
# track all solutions
    solutions = list()
# generate an initial point
    solution = bounds[:, 0] + rand(len(bounds)) * (bounds[:, 1] - bounds[:, 0])
# list of changes made to each variable
    change = [0.0 for _ in range(bounds.shape[0])]
# run the gradient descent
    for it in range(n_iter):
# calculate the projected solution
        projected = [solution[i] + momentum * change[i] for i in range(solution.shape[0])]
# calculate the gradient for the projection
        gradient = derivative(projected[0], projected[1])
# build a solution one variable at a time
        new_solution = list()
        for i in range(solution.shape[0]):
# calculate the change
            change[i] = (momentum * change[i]) - step_size * gradient[i]
# calculate the new position in this variable
            value = solution[i] + change[i]
# store this variable
            new_solution.append(value)
# store the new solution
        solution = asarray(new_solution)
        solutions.append(solution)
# evaluate candidate point
        solution_eval = objective(solution[0], solution[1])
# report progress
        print('>%d f(%s) = %.5f' % (it, solution, solution_eval))
    return solutions
```


```python
# seed the pseudo random number generator
seed(1)
# define range for input
bounds = asarray([[-1.0, 1.0], [-1.0, 1.0]])
# define the total iterations
n_iter = 50
# define the step size
step_size = 0.01
# define momentum
momentum = 0.8
# perform the gradient descent search with nesterov momentum
solutions = nesterov(objective, derivative, bounds, n_iter, step_size, momentum)
```

    >0 f([-0.16263687  0.43183601]) = 0.26920
    >1 f([-0.15678194  0.41628991]) = 0.25951
    >2 f([-0.14905604  0.39577597]) = 0.24672
    >3 f([-0.14001781  0.37177753]) = 0.23176
    >4 f([-0.13013149  0.34552719]) = 0.21540
    >5 f([-0.11977798  0.31803639]) = 0.19826
    >6 f([-0.10926527  0.29012287]) = 0.18086
    >7 f([-0.09883799  0.26243621]) = 0.16360
    >8 f([-0.08868625  0.23548115]) = 0.14679
    >9 f([-0.07895356  0.20963876]) = 0.13069
    >10 f([-0.06974406  0.18518555]) = 0.11544
    >11 f([-0.06112894  0.16231052]) = 0.10118
    >12 f([-0.0531521   0.14113029]) = 0.08798
    >13 f([-0.04583521  0.12170238]) = 0.07587
    >14 f([-0.03918207  0.10403685]) = 0.06485
    >15 f([-0.03318236  0.08810634]) = 0.05492
    >16 f([-0.02781495  0.0738547 ]) = 0.04604
    >17 f([-0.0230506   0.06120431]) = 0.03815
    >18 f([-0.01885433  0.05006232]) = 0.03121
    >19 f([-0.01518737  0.04032576]) = 0.02514
    >20 f([-0.01200873  0.03188577]) = 0.01988
    >21 f([-0.0092765   0.02463111]) = 0.01535
    >22 f([-0.0069489   0.01845084]) = 0.01150
    >23 f([-0.00498509  0.01323648]) = 0.00825
    >24 f([-0.00334575  0.0088837 ]) = 0.00554
    >25 f([-0.0019936   0.00529344]) = 0.00330
    >26 f([-0.00089364  0.00237281]) = 0.00148
    >27 f([-1.34014200e-05  3.55836635e-05]) = 0.00002
    >28 f([ 0.00067698 -0.00179752]) = -0.00112
    >29 f([ 0.00120469 -0.00319872]) = -0.00199
    >30 f([ 0.00159433 -0.00423328]) = -0.00264
    >31 f([ 0.00186791 -0.00495972]) = -0.00309
    >32 f([ 0.00204505 -0.00543005]) = -0.00338
    >33 f([ 0.00214302 -0.00569019]) = -0.00355
    >34 f([ 0.00217697 -0.00578033]) = -0.00360
    >35 f([ 0.00216005 -0.0057354 ]) = -0.00358
    >36 f([ 0.00210358 -0.00558546]) = -0.00348
    >37 f([ 0.00201724 -0.0053562 ]) = -0.00334
    >38 f([ 0.0019092  -0.00506934]) = -0.00316
    >39 f([ 0.00178631 -0.00474305]) = -0.00296
    >40 f([ 0.00165425 -0.00439238]) = -0.00274
    >41 f([ 0.00151762 -0.00402961]) = -0.00251
    >42 f([ 0.00138015 -0.0036646 ]) = -0.00228
    >43 f([ 0.00124477 -0.00330514]) = -0.00206
    >44 f([ 0.00111374 -0.00295723]) = -0.00184
    >45 f([ 0.00098874 -0.00262532]) = -0.00164
    >46 f([ 0.00087096 -0.00231259]) = -0.00144
    >47 f([ 0.0007612  -0.00202116]) = -0.00126
    >48 f([ 0.00065993 -0.00175226]) = -0.00109
    >49 f([ 0.00056733 -0.00150639]) = -0.00094
    


```python
# sample input range uniformly at 0.1 increments
xaxis = arange(bounds[0,0], bounds[0,1], 0.1)
yaxis = arange(bounds[1,0], bounds[1,1], 0.1)
# create a mesh from the axis
x, y = meshgrid(xaxis, yaxis)
# compute targets
results = objective(x, y)
# create a filled contour plot with 50 levels and jet color scheme
pyplot.contourf(x, y, results, levels=50, cmap='jet')
```




    <matplotlib.contour.QuadContourSet at 0x1ee689cf820>




    
![png](output_7_1.png)
    



```python

# example of plotting the nesterov momentum search on a contour plot of the test function
from math import sqrt
from numpy import asarray
from numpy import arange
from numpy.random import rand
from numpy.random import seed
from numpy import meshgrid
from matplotlib import pyplot
from mpl_toolkits.mplot3d import Axes3D
 
# objective function
def objective(x, y):
    return x + y
 
# derivative of objective function
def derivative(x, y):
    return asarray([x , y ])
 
# gradient descent algorithm with nesterov momentum
def nesterov(objective, derivative, bounds, n_iter, step_size, momentum):
# track all solutions
    solutions = list()
# generate an initial point
    solution = bounds[:, 0] + rand(len(bounds)) * (bounds[:, 1] - bounds[:, 0])
# list of changes made to each variable
    change = [0.0 for _ in range(bounds.shape[0])]
# run the gradient descent
    for it in range(n_iter):
# calculate the projected solution
        projected = [solution[i] + momentum * change[i] for i in range(solution.shape[0])]
# calculate the gradient for the projection
        gradient = derivative(projected[0], projected[1])
# build a solution one variable at a time
        new_solution = list()
        for i in range(solution.shape[0]):
# calculate the change
            change[i] = (momentum * change[i]) - step_size * gradient[i]
# calculate the new position in this variable
            value = solution[i] + change[i]
# store this variable
            new_solution.append(value)
# store the new solution
        solution = asarray(new_solution)
        solutions.append(solution)
# evaluate candidate point
        solution_eval = objective(solution[0], solution[1])
# report progress
        print('>%d f(%s) = %.5f' % (it, solution, solution_eval))
    return solutions
 
# seed the pseudo random number generator
seed(1)
# define range for input
bounds = asarray([[-1.0, 1.0], [-1.0, 1.0]])
# define the total iterations
n_iter = 50
# define the step size
step_size = 0.01
# define momentum
momentum = 0.8
# perform the gradient descent search with nesterov momentum
solutions = nesterov(objective, derivative, bounds, n_iter, step_size, momentum)
# sample input range uniformly at 0.1 increments
xaxis = arange(bounds[0,0], bounds[0,1], 0.1)
yaxis = arange(bounds[1,0], bounds[1,1], 0.1)
# create a mesh from the axis
x, y = meshgrid(xaxis, yaxis)
# compute targets
results = objective(x, y)
# create a filled contour plot with 50 levels and jet color scheme
pyplot.contourf(x, y, results, levels=50, cmap='jet')
# plot the sample as black circles
solutions = asarray(solutions)
pyplot.plot(solutions[:, 0], solutions[:, 1], '.-', color='w')
# show the plot
pyplot.show()
```

    >0 f([-0.16429643  0.4362425 ]) = 0.27195
    >1 f([-0.16133909  0.42839013]) = 0.26705
    >2 f([-0.15738349  0.41788716]) = 0.26050
    >3 f([-0.15267682  0.40538993]) = 0.25271
    >4 f([-0.14742237  0.39143823]) = 0.24402
    >5 f([-0.14178662  0.3764741 ]) = 0.23469
    >6 f([-0.13590524  0.36085776]) = 0.22495
    >7 f([-0.12988814  0.34488105]) = 0.21499
    >8 f([-0.12382371  0.32877868]) = 0.20495
    >9 f([-0.11778244  0.31273782]) = 0.19496
    >10 f([-0.11181994  0.29690608]) = 0.18509
    >11 f([-0.10597943  0.28139828]) = 0.17542
    >12 f([-0.10029396  0.26630212]) = 0.16601
    >13 f([-0.09478813  0.25168294]) = 0.15689
    >14 f([-0.08947962  0.23758772]) = 0.14811
    >15 f([-0.08438049  0.22404843]) = 0.13967
    >16 f([-0.07949818  0.21108483]) = 0.13159
    >17 f([-0.0748364  0.1987068]) = 0.12387
    >18 f([-0.07039591  0.18691634]) = 0.11652
    >19 f([-0.06617508  0.17570913]) = 0.10953
    >20 f([-0.06217044  0.16507593]) = 0.10291
    >21 f([-0.05837705  0.15500368]) = 0.09663
    >22 f([-0.05478892  0.14547642]) = 0.09069
    >23 f([-0.05139923  0.13647606]) = 0.08508
    >24 f([-0.04820061  0.12798302]) = 0.07978
    >25 f([-0.04518529  0.1199767 ]) = 0.07479
    >26 f([-0.0423453   0.11243593]) = 0.07009
    >27 f([-0.03967258  0.10533928]) = 0.06567
    >28 f([-0.03715906  0.09866534]) = 0.06151
    >29 f([-0.03479676  0.09239292]) = 0.05760
    >30 f([-0.03257786  0.08650124]) = 0.05392
    >31 f([-0.0304947   0.08097002]) = 0.05048
    >32 f([-0.0285399   0.07577959]) = 0.04724
    >33 f([-0.02670629  0.07091097]) = 0.04420
    >34 f([-0.02498701  0.06634592]) = 0.04136
    >35 f([-0.02337548  0.06206694]) = 0.03869
    >36 f([-0.02186538  0.05805731]) = 0.03619
    >37 f([-0.02045074  0.05430112]) = 0.03385
    >38 f([-0.01912583  0.0507832 ]) = 0.03166
    >39 f([-0.01788524  0.04748918]) = 0.02960
    >40 f([-0.01672385  0.04440542]) = 0.02768
    >41 f([-0.01563678  0.04151903]) = 0.02588
    >42 f([-0.01461946  0.03881782]) = 0.02420
    >43 f([-0.01366754  0.03629028]) = 0.02262
    >44 f([-0.01277695  0.03392557]) = 0.02115
    >45 f([-0.01194384  0.03171346]) = 0.01977
    >46 f([-0.01116457  0.02964434]) = 0.01848
    >47 f([-0.01043574  0.02770915]) = 0.01727
    >48 f([-0.00975415  0.02589939]) = 0.01615
    >49 f([-0.0091168   0.02420706]) = 0.01509
    


    
![png](output_8_1.png)
    



```python

```
